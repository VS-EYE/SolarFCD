"""
Reusable building blocks (attention / inception / residual) used by models.py.
These are the blocks defined in notebooks/Base.ipynb, unchanged in behaviour and
collected here so they can be imported instead of copy-pasted.
"""

import keras.backend as K
from tensorflow.keras import layers
from tensorflow.keras.layers import (
    Activation, Add, BatchNormalization, Concatenate, Conv2D, Dense, Dropout,
    GlobalAveragePooling2D, GlobalMaxPooling2D, Lambda, LeakyReLU,
    MaxPooling2D, Permute, Reshape, SeparableConv2D, concatenate, multiply,
)


# --------------------------------------------------------------------------- #
# Squeeze-and-Excitation
# --------------------------------------------------------------------------- #
def se_block(input_tensor, ratio=16):
    num_channels = input_tensor.shape[-1]
    squeeze = GlobalAveragePooling2D()(input_tensor)
    excitation = Dense(num_channels // ratio, activation="relu")(squeeze)
    excitation = Dense(num_channels, activation="sigmoid")(excitation)
    excitation = Reshape((1, 1, num_channels))(excitation)
    return multiply([input_tensor, excitation])


# --------------------------------------------------------------------------- #
# CBAM: channel + spatial attention
# --------------------------------------------------------------------------- #
def channel_attention(input_feature, ratio=8):
    channel_axis = 1 if K.image_data_format() == "channels_first" else -1
    channel = input_feature.shape[channel_axis]

    shared_one = Dense(channel // ratio, activation="relu",
                       kernel_initializer="he_normal",
                       use_bias=True, bias_initializer="zeros")
    shared_two = Dense(channel, kernel_initializer="he_normal",
                       use_bias=True, bias_initializer="zeros")

    avg_pool = GlobalAveragePooling2D()(input_feature)
    avg_pool = Reshape((1, 1, channel))(avg_pool)
    avg_pool = shared_two(shared_one(avg_pool))

    max_pool = GlobalMaxPooling2D()(input_feature)
    max_pool = Reshape((1, 1, channel))(max_pool)
    max_pool = shared_two(shared_one(max_pool))

    cbam_feature = Add()([avg_pool, max_pool])
    cbam_feature = Activation("sigmoid")(cbam_feature)

    if K.image_data_format() == "channels_first":
        cbam_feature = Permute((3, 1, 2))(cbam_feature)
    return multiply([input_feature, cbam_feature])


def spatial_attention(input_feature, kernel_size=7):
    if K.image_data_format() == "channels_first":
        cbam_feature = Permute((2, 3, 1))(input_feature)
    else:
        cbam_feature = input_feature

    avg_pool = Lambda(lambda x: K.mean(x, axis=3, keepdims=True))(cbam_feature)
    max_pool = Lambda(lambda x: K.max(x, axis=3, keepdims=True))(cbam_feature)
    concat = Concatenate(axis=3)([avg_pool, max_pool])
    cbam_feature = Conv2D(1, kernel_size, strides=1, padding="same",
                          activation="sigmoid",
                          kernel_initializer="he_normal", use_bias=False)(concat)

    if K.image_data_format() == "channels_first":
        cbam_feature = Permute((3, 1, 2))(cbam_feature)
    return multiply([input_feature, cbam_feature])


def cbam_block(cbam_feature, ratio=8):
    return spatial_attention(channel_attention(cbam_feature, ratio))


# --------------------------------------------------------------------------- #
# Residual blocks
# --------------------------------------------------------------------------- #
def residual_block(input_tensor, filters, kernel_size=(3, 3),
                   strides=(1, 1), activation="relu"):
    x = Conv2D(filters, kernel_size, strides=strides, padding="same")(input_tensor)
    x = BatchNormalization()(x)
    x = Activation(activation)(x)
    x = Conv2D(filters, kernel_size, padding="same")(x)
    x = BatchNormalization()(x)

    if strides != (1, 1) or input_tensor.shape[-1] != filters:
        shortcut = Conv2D(filters, (1, 1), strides=strides, padding="same")(input_tensor)
        shortcut = BatchNormalization()(shortcut)
        x = Add()([x, shortcut])
    else:
        x = Add()([x, input_tensor])
    return Activation(activation)(x)


def separable_residual(input_tensor, filters, kernel_size=(3, 3),
                       strides=(1, 1), activation="relu"):
    x = SeparableConv2D(filters, kernel_size, strides=strides, padding="same")(input_tensor)
    x = BatchNormalization()(x)
    x = LeakyReLU(alpha=0.2)(x)
    x = SeparableConv2D(filters, kernel_size, padding="same")(x)
    x = BatchNormalization()(x)

    y = SeparableConv2D(filters, kernel_size, strides=strides, padding="same")(input_tensor)
    y = BatchNormalization()(y)

    if strides != (1, 1) or input_tensor.shape[-1] != filters:
        shortcut = SeparableConv2D(filters, (1, 1), strides=strides, padding="same")(input_tensor)
        shortcut = BatchNormalization()(shortcut)
        x = Add()([x, shortcut])
    else:
        x = Add()([x, y, input_tensor])
    return Activation(activation)(x)


# --------------------------------------------------------------------------- #
# Inception-style blocks
# --------------------------------------------------------------------------- #
def inception_module(x, filters):
    conv1x1 = Conv2D(filters, (1, 1), padding="same", activation="relu")(x)
    conv3x3 = Conv2D(filters, (3, 3), padding="same", activation="relu")(x)
    conv5x5 = Conv2D(filters, (5, 5), padding="same", activation="relu")(x)
    max_pool = MaxPooling2D((3, 3), strides=(1, 1), padding="same")(x)
    max_pool = Conv2D(filters, (1, 1), padding="same", activation="relu")(max_pool)
    return Concatenate()([conv1x1, conv3x3, conv5x5, max_pool])


def naive_inception_module(input_tensor, num_filters, gelu_leaky=False):
    """gelu_leaky=True reproduces the GELU + LeakyReLU variant from the notebook."""
    act = "gelu" if gelu_leaky else "relu"

    def maybe_leaky(t):
        return LeakyReLU(alpha=0.2)(t) if gelu_leaky else t

    conv1x1 = maybe_leaky(Conv2D(num_filters, (1, 1), padding="same", activation=act)(input_tensor))

    conv3x3 = maybe_leaky(Conv2D(num_filters, (1, 1), padding="same", activation=act)(input_tensor))
    conv3x3 = maybe_leaky(Conv2D(num_filters, (3, 3), padding="same", activation=act)(conv3x3))

    conv5x5 = maybe_leaky(Conv2D(num_filters, (1, 1), padding="same", activation=act)(input_tensor))
    conv5x5 = maybe_leaky(Conv2D(num_filters, (5, 5), padding="same", activation=act)(conv5x5))

    max_pool = MaxPooling2D((3, 3), strides=(1, 1), padding="same")(input_tensor)
    max_pool = maybe_leaky(Conv2D(num_filters, (1, 1), padding="same", activation=act)(max_pool))

    return concatenate([conv1x1, conv3x3, conv5x5, max_pool], axis=-1)


# --------------------------------------------------------------------------- #
# Misc
# --------------------------------------------------------------------------- #
def attention_block(input_tensor, num_filters):
    x = Conv2D(num_filters, (4, 4), padding="same")(input_tensor)
    x = LeakyReLU(alpha=0.2)(BatchNormalization()(x))

    y = Conv2D(num_filters, (3, 3), padding="same")(x)
    y = LeakyReLU(alpha=0.2)(BatchNormalization()(y))

    z = Conv2D(num_filters, (3, 3), padding="same")(x)
    z = LeakyReLU(alpha=0.2)(BatchNormalization()(z))
    z = Conv2D(num_filters, (2, 2), padding="same")(z)
    z = LeakyReLU(alpha=0.2)(BatchNormalization()(z))
    z = Dropout(0.2)(z)

    zz = Conv2D(num_filters, (3, 3), padding="same")(input_tensor)
    zz = LeakyReLU(alpha=0.2)(BatchNormalization()(zz))
    zz = Conv2D(num_filters, (4, 4), padding="same")(zz)
    zz = LeakyReLU(alpha=0.2)(BatchNormalization()(zz))
    zz = Dropout(0.2)(zz)

    out1 = layers.concatenate([y, z, zz])
    return layers.concatenate([out1, zz])


def dense_block(x, num_layers, growth_rate):
    for _ in range(num_layers):
        y = Dense(growth_rate, activation="relu")(x)
        x = concatenate([x, y])
    return x
