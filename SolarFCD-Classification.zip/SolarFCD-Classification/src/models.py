"""
Model factory for SolarFCD.

Every architecture reported in the paper is built by the single entry point
`create_model(...)`:

    backbone : frozen ImageNet-pretrained feature extractor
    attention: optional attention head applied to the backbone output
    head     : Flatten -> Dense(n_classes, softmax)

Examples
--------
    create_model("vgg19",     4, Adam(1e-3))                       # VGG19
    create_model("densenet121", 4, Adam(1e-3))                     # D121
    create_model("mobilenet", 4, Adam(1e-3), attention="channel")  # MBCA
    create_model("mobilenet", 4, Adam(1e-3), attention="cbam")
    create_model("vit_b16",   4, Adam(1e-3))                       # needs vit-keras
"""

from tensorflow import keras
from tensorflow.keras import applications as apps
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.models import Model

from blocks import cbam_block, channel_attention, se_block

METRICS = [
    keras.metrics.CategoricalAccuracy(name="accuracy"),
    keras.metrics.Precision(name="precision"),
    keras.metrics.Recall(name="recall"),
    keras.metrics.AUC(name="auc"),
]

BACKBONES = {
    "vgg16": apps.VGG16,
    "vgg19": apps.VGG19,
    "resnet50": apps.ResNet50,
    "densenet121": apps.DenseNet121,
    "densenet201": apps.DenseNet201,
    "mobilenet": apps.MobileNet,
    "mobilenetv2": apps.MobileNetV2,
    "inceptionv3": apps.InceptionV3,
    "xception": apps.Xception,
    "efficientnetb0": apps.EfficientNetB0,
}

SHORT_NAMES = {
    "vgg19": "V19", "vgg16": "V16", "densenet121": "D121", "densenet201": "D201",
    "resnet50": "R50", "mobilenet": "MB", "mobilenetv2": "MBV2",
    "inceptionv3": "IV3", "xception": "XCP", "efficientnetb0": "EB0",
    "vit_b16": "ViTB16",
}

ATTENTIONS = {
    "none": None,
    "channel": channel_attention,   # -> "MBCA" when combined with MobileNet
    "se": se_block,
    "cbam": cbam_block,
}


def _build_backbone(name, input_shape, n_classes):
    name = name.lower()
    if name in BACKBONES:
        return BACKBONES[name](include_top=False, weights="imagenet",
                               input_shape=input_shape)
    if name in ("vit_b16", "vit_b32"):
        try:
            from vit_keras import vit
        except ImportError as exc:                       # pragma: no cover
            raise ImportError(
                "vit_b16 requires `pip install vit-keras`, which currently "
                "supports Keras 2 only. Run the ViT experiments in the "
                "TF 2.15 / Keras 2 environment described in the README."
            ) from exc
        builder = vit.vit_b16 if name == "vit_b16" else vit.vit_b32
        return builder(image_size=input_shape[:2], pretrained=True,
                       include_top=False, pretrained_top=False,
                       classes=n_classes, activation="softmax")
    raise ValueError(f"Unknown backbone '{name}'. Options: "
                     f"{sorted(BACKBONES) + ['vit_b16', 'vit_b32']}")


def create_model(backbone, n_classes, optimizer,
                 input_shape=(224, 224, 3),
                 attention="none",
                 trainable_base=False,
                 loss="categorical_crossentropy"):
    """Build + compile a transfer-learning classifier."""
    attention = (attention or "none").lower()
    if attention not in ATTENTIONS:
        raise ValueError(f"attention must be one of {sorted(ATTENTIONS)}")

    conv_base = _build_backbone(backbone, input_shape, n_classes)
    conv_base.trainable = trainable_base          # frozen by default, as in the paper

    x = conv_base.output
    fn = ATTENTIONS[attention]
    if fn is not None:
        x = fn(x)
    x = Flatten()(x)
    x = Dense(n_classes, activation="softmax")(x)

    tag = SHORT_NAMES.get(backbone.lower(), backbone.upper())
    suffix = {"none": "", "channel": "_CA", "se": "_SE", "cbam": "_CBAM"}[attention]
    model = Model(inputs=conv_base.input, outputs=x, name=f"{tag}{suffix}")

    model.compile(optimizer=optimizer, loss=loss, metrics=METRICS)
    return model
