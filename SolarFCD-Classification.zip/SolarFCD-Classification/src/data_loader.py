"""
Data pipeline for SolarFCD.

Reproduces exactly the generators used in notebooks/Base.ipynb:
  * train : rescale 1/255 + width/height shift 0.2 + horizontal & vertical flip
  * valid : rescale 1/255 only
  * test  : rescale 1/255 only, shuffle=False (required for the confusion matrix)

Class order is FIXED and passed explicitly so label indices are identical on
every machine and every run:
    0 Electrical_Fault | 1 Healthy | 2 Structural_Fault | 3 Surface_Obstruction
"""

from pathlib import Path

from tensorflow.keras.preprocessing.image import ImageDataGenerator

CLASSES = [
    "Electrical_Fault",
    "Healthy",
    "Structural_Fault",
    "Surface_Obstruction",
]

IMG_WIDTH, IMG_HEIGHT, N_CHANNELS = 224, 224, 3
IMAGE_SHAPE = (IMG_WIDTH, IMG_HEIGHT, N_CHANNELS)


def build_generators(data_root,
                     img_size=(IMG_WIDTH, IMG_HEIGHT),
                     batch_size=64,
                     augment=True,
                     seed=42):
    """Return (train_gen, valid_gen, test_gen)."""
    data_root = Path(data_root)
    train_dir, valid_dir, test_dir = (data_root / s for s in ("Train", "Valid", "Test"))
    for d in (train_dir, valid_dir, test_dir):
        if not d.is_dir():
            raise FileNotFoundError(
                f"{d} not found. Run `python src/download_dataset.py --out data` first, "
                f"or point --data-root at the folder that contains Train/ Valid/ Test/."
            )

    if augment:
        train_datagen = ImageDataGenerator(
            rescale=1.0 / 255,
            width_shift_range=0.2,
            height_shift_range=0.2,
            horizontal_flip=True,
            vertical_flip=True,
        )
    else:
        train_datagen = ImageDataGenerator(rescale=1.0 / 255)

    eval_datagen = ImageDataGenerator(rescale=1.0 / 255)

    common = dict(classes=CLASSES, target_size=img_size,
                  batch_size=batch_size, class_mode="categorical")

    train_gen = train_datagen.flow_from_directory(
        train_dir, shuffle=True, seed=seed, **common)
    valid_gen = eval_datagen.flow_from_directory(
        valid_dir, shuffle=True, seed=seed, **common)
    test_gen = eval_datagen.flow_from_directory(
        test_dir, shuffle=False, **common)   # never shuffle the test set

    return train_gen, valid_gen, test_gen
