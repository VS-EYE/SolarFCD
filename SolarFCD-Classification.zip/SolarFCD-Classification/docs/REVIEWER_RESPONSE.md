# Response to Reviewer Comment — Code Availability

> **Reviewer comment:** *"Along with Data availability, Code Availability should
> also be provided on GitHub or any other platform."*

**Response.** We thank the reviewer for this constructive comment. We fully agree
that the source code should be openly available alongside the dataset to support
transparency and reproducibility. Accordingly, we have released the complete
implementation in a public GitHub repository and added a *Code Availability*
statement to the manuscript.

The repository contains the full pipeline used to obtain every result reported in
the paper:

1. an automated download-and-verification script for the SolarFCD dataset
   (`src/download_dataset.py`), so reviewers and readers can obtain the exact data
   with a single command;
2. the data-loading pipeline with a fixed class ordering, guaranteeing identical
   label indices across machines (`src/data_loader.py`);
3. all model definitions, including the attention modules (SE, channel attention,
   CBAM) and the transfer-learning backbones evaluated in the comparison table
   (`src/models.py`, `src/blocks.py`);
4. training and evaluation entry points with fully documented command-line
   arguments and fixed random seeds (`src/train.py`, `src/evaluate.py`);
5. the reference Jupyter notebook (`notebooks/Base.ipynb`);
6. a `README.md` giving step-by-step installation, dataset-download and
   execution instructions, and a pinned `requirements.txt` specifying the exact
   software environment.

All previously hard-coded local file paths have been replaced by command-line
arguments, so the code runs unmodified on any machine. The repository is released
under the MIT license and includes a `CITATION.cff` file. The corresponding text
has been added to the manuscript (Section: *Declarations*), as shown below.

---

## Text added to the manuscript

### Data Availability Statement

> The SolarFCD dataset used in this study is publicly available from the DFKI
> Cloud repository at
> <https://cloud.dfki.de/owncloud/index.php/s/SZYo97gdwY2k92Z>.
> The dataset comprises 3,742 solar-panel images organised into predefined
> training (3,030), validation (337) and test (375) splits across four classes:
> *Electrical_Fault*, *Healthy*, *Structural_Fault* and *Surface_Obstruction*.

### Code Availability Statement

> The complete source code supporting the findings of this study — including
> data preparation, model implementation, training and evaluation scripts — is
> openly available in the GitHub repository
> <https://github.com/&lt;your-username&gt;/SolarFCD-Classification>
> (archived at Zenodo, DOI: &lt;10.5281/zenodo.XXXXXXX&gt;).
> The repository is released under the MIT license and provides step-by-step
> instructions for downloading the dataset, reproducing the training procedure
> and regenerating all reported evaluation metrics.

---

## Short version (if the journal allows only a brief reply)

> We thank the reviewer for this suggestion. The full source code has now been
> released publicly at
> <https://github.com/&lt;your-username&gt;/SolarFCD-Classification>, together with
> documentation covering environment setup, automated dataset download from the
> DFKI Cloud repository, training and evaluation. A *Code Availability*
> statement has been added to the Declarations section of the revised manuscript.

---

### Before submitting, replace

| Placeholder | Replace with |
|---|---|
| `<your-username>` | your GitHub username or organisation |
| `<10.5281/zenodo.XXXXXXX>` | the Zenodo DOI (see below) |
| `<Paper title>`, `<Authors>`, `<Journal>` | your manuscript details |

**Getting a Zenodo DOI (strongly recommended — many journals require an archived,
immutable snapshot rather than a mutable GitHub URL):**

1. Sign in at <https://zenodo.org> with your GitHub account.
2. Under *GitHub*, toggle the switch next to `SolarFCD-Classification` to **On**.
3. In GitHub, create a release (`v1.0.0`).
4. Zenodo mints a DOI automatically; copy the DOI badge into the README and the
   Code Availability statement.
